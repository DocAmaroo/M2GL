#ifndef PARKING
#define PARKING

#include <iostream>
#include <Arduino.h> 
#include "OSRMService.h"
#include "DistanceLigneDroiteService.h"
#include "DistanceService.h"

class Parking {
private:
  String id;
  String name;
  float longi;
  float lati;
  int places;
  int placesLibres;

public:
  Parking(String id, String name, float longi, float lati);

  int getNbPlaces() const;
  int getPlacesLibres() const;
  
  void setNbPlaces(int nbPlaces);
  void setPlacesLibres(int placesLibres);

  String getId() const;
  String getName() const;
  
  float getDistance(float longi, float lati) const;
  float getDistance(float longi, float lati, DistanceService& distanceService) const;
};

#endif

#ifndef DISTANCELIGNEDROITESERVICE
#define DISTANCELIGNEDROITESERVICE

#include "DistanceService.h"

class DistanceLigneDroiteService : public DistanceService
{
  public:
    float getDistance(float longitude1, float latitude1, float longitude2, float latitude2);
};

#endif

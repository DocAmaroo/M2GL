#ifndef PARKINGSSERVICE
#define PARKINGSSERVICE

#define MONTPELLIER3M_URL "https://data.montpellier3m.fr/sites/default/files/ressources/"
#define MONTPELLIER3M_XML".xml"

#include <map>
#include <HTTPClient.h>
#include <Arduino.h>

class ParkingsService
{
private:
  HTTPClient http;
public:
    std::map<String, String> getParkingInfos(const String id);
};

#endif

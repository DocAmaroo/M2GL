#include "DistanceLigneDroiteService.h"
#include <math.h>

float DistanceLigneDroiteService::getDistance(float longitude1, float latitude1, float longitude2, float latitude2) {
  return sqrt((latitude1 - latitude2) * (latitude1 - latitude2) + (longitude1 - longitude2) * (longitude1 - longitude2));
}

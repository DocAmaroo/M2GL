#ifndef OSRMSERVICE
#define OSRMSERVICE

#define OSRM_URL "https://router.project-osrm.org/route/v1/driving/"

#include "DistanceService.h"

#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <map>

class OSRMService : public DistanceService
{
private:
  HTTPClient http;
  float lastLongi = -1;
  float lastLati = -1;
  std::map<String, float> cache;
  
public:
  float getDistance(float longitude1, float latitude1, float longitude2, float latitude2);
  
};

#endif

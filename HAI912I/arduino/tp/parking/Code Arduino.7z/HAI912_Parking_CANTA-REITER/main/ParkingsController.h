#ifndef PARKINGSCONTROLLER
#define PARKINGSCONTROLLER

#define OSRM_URL "https://router.project-osrm.org/route/v1/driving/"

#include "ParkingsService.h"
#include "Parking.h"
#include <vector>

class ParkingsController
{
private:
  ParkingsService& service;
  std::vector<Parking> parkings;

public:
  ParkingsController(ParkingsService& service);
  const std::vector<Parking>& getParkings() const;
  const std::vector<Parking>& getNearestParkings(float longitude, float latitude, DistanceService& distanceService, int nbParkings = 5);
};

#endif

#include "Parking.h"

Parking::Parking(String id, String name, float longi, float lati) : 
  id(id), name(name), longi(longi), lati(lati), placesLibres(0), places(0)
{
}

void Parking::setNbPlaces(int nbPlaces)
{
  places = nbPlaces;
}

void Parking::setPlacesLibres(int nbPlacesLibres)
{
  placesLibres = nbPlacesLibres;
}

int Parking::getPlacesLibres() const
{
  return placesLibres;
}

int Parking::getNbPlaces() const
{
  return places;
}

String Parking::getId() const
{
  return id;
}

String Parking::getName() const 
{
  return name;
}

float Parking::getDistance(float longi, float lati) const {
  // OSRMService service;
  DistanceLigneDroiteService service;
  return getDistance(longi, lati, service);
}

float Parking::getDistance(float longi, float lati, DistanceService& distanceService) const {
  return distanceService.getDistance(this->longi, this->lati, longi, lati);
}

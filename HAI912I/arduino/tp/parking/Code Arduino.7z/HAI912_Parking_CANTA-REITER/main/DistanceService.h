#ifndef DISTANCESERVICE
#define DISTANCESERVICE

class DistanceService {
  public:
    virtual float getDistance(float longitude1, float latitude1, float longitude2, float latitude2) = 0;
};

#endif

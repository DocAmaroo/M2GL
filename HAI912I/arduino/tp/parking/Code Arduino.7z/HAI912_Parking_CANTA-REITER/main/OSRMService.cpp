#include "OSRMService.h"

float OSRMService::getDistance(float longi1, float lati1, float longi2, float lati2) {
  if(lastLongi != longi2 || lastLati != lati2) {
    cache.clear();

    lastLongi = longi2;
    lastLati = lati2;
  }

  String latilong1 = String(longi1) + ";" + String(lati1);

  if(cache.count(latilong1) <= 0) {

    http.begin(String(OSRM_URL) + longi1 + "," + lati1 + ";" + longi2 + "," + lati2);

    int codeHTTP = http.GET();
    if(codeHTTP > 0) {
      if(codeHTTP == HTTP_CODE_OK || codeHTTP == HTTP_CODE_MOVED_PERMANENTLY) {
        String payload = http.getString();
        
        StaticJsonDocument<200> filter;
        filter["routes"][0]["distance"] = true;
        filter["routes"][0]["duration"] = true;
  
        StaticJsonDocument<400> doc;
  
        DeserializationError error = deserializeJson(doc, payload, DeserializationOption::Filter(filter));
        if (error) {
          Serial.print(F("deserializationJson() failed: "));
          Serial.println(error.f_str());
        }
        
        
        float distance = doc["routes"][0]["distance"];
        cache[latilong1] = distance;
      }
    } 
  }
  
  return cache[latilong1];
}

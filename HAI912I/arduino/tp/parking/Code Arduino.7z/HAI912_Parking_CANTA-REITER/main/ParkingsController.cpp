#include "ParkingsController.h"
#include <HTTPClient.h>

ParkingsController::ParkingsController(ParkingsService& service) : service(service)
{
  // parkings.push_back(Parking());
  parkings.push_back(Parking("FR_MTP_ANTI", "Antigone", 3.888818930000000, 43.608716059999999));
  parkings.push_back(Parking("FR_MTP_COME", "Comédie", 3.879761960000000, 43.608560920000002));
  parkings.push_back(Parking("FR_MTP_CORU", "Corum", 3.882257730000000, 43.613888209999999));
  parkings.push_back(Parking("FR_MTP_EURO", "Europa", 3.892530740000000, 43.607849710000004));
  parkings.push_back(Parking("FR_MTP_FOCH", "Foch Préfecture", 3.876570840000000, 43.610749120000001));
  parkings.push_back(Parking("FR_MTP_GAMB", "Gambetta", 3.871374360000000, 43.606951379999998));
  parkings.push_back(Parking("FR_MTP_GARE", "Saint Roch", 3.878550720000000, 43.603291489999997));
  parkings.push_back(Parking("FR_MTP_TRIA", "Triangle", 3.881844180000000, 43.609233840000002));
  parkings.push_back(Parking("FR_MTP_ARCT", "Arc de Triomphe", 3.873200750000000, 43.611002669999998));
  parkings.push_back(Parking("FR_MTP_PITO", "Pitot", 3.870191170000000, 43.612244939999997));
  parkings.push_back(Parking("FR_MTP_CIRC", "Circé Odysseum", 3.917849500000000, 43.604953770000002));
  parkings.push_back(Parking("FR_MTP_SABI", "Sabines", 3.860224600000000, 43.583832630000003));
  parkings.push_back(Parking("FR_MTP_GARC", "Garcia Lorca", 3.890715800000000, 43.590985089999997));
  parkings.push_back(Parking("FR_CAS_SABL", "Notre Dame de Sablassou", 3.922295360000000, 43.634191940000001));
  parkings.push_back(Parking("FR_MTP_MOSS", "Mosson", 3.819665540000000, 43.616237159999997));
  parkings.push_back(Parking("FR_STJ_SJLC", "Saint-Jean-le-Sec", 3.837931200000000, 43.570822249999999));
  parkings.push_back(Parking("FR_MTP_MEDC", "Euromédecine", 3.827723650000000, 43.638953590000000));
  parkings.push_back(Parking("FR_MTP_OCCI", "Occitanie", 3.848597960000000, 43.634562320000001));
  parkings.push_back(Parking("FR_CAS_CDGA", "Charles de Gaulle", 3.897762100000000, 43.628542119999999));
  parkings.push_back(Parking("FR_MTP_ARCE", "Arceaux", 3.867490670000000, 43.611716469999998));
  parkings.push_back(Parking("FR_MTP_POLY", "Polygone", 3.884765390000000, 43.608370960000002));
  parkings.push_back(Parking("FR_MTP_GA109", "Multiplexe (est)", 3.918980000000000, 43.605060000000000));
  parkings.push_back(Parking("FR_MTP_GA250", "Multiplexe (ouest)", 3.914030000000000, 43.604000000000000));

  // Parkings sans données temps réel
  // parkings.push_back(Parking("", "Peyrou", 3.870383780000000, 43.611297000000000));
  // parkings.push_back(Parking("", "Hôtel de ville", 3.895853270000000, 43.599231000000003));
  // parkings.push_back(Parking("", "Jacou", 3.912884750000000, 43.654598700000001));
  // parkings.push_back(Parking("", "Georges Pompidou", 3.921084190000000, 43.649339200000000));
  // parkings.push_back(Parking("", "Via Domitia", 3.929538080000000, 43.646658010000003));
  // parkings.push_back(Parking("", "Juvignac", 3.809621860000000, 43.617403740000000));
  // parkings.push_back(Parking("", "Saint-Jean-de-Védas Centre", 3.830585520000000, 43.574962790000001));
  // parkings.push_back(Parking("", "Lattes", 3.904817620000000, 43.570809879999999));
  // parkings.push_back(Parking("", "Parc expo", 3.945678520000000, 43.572910210000003));
  // parkings.push_back(Parking("", "Pérols centre", 3.957355560000000, 43.565378570000000));
  // parkings.push_back(Parking("", "Décathlon", 3.923800380000000, 43.606185590000003));
  // parkings.push_back(Parking("", "Ikéa", 3.925582560000000, 43.604609619999998));
  // parkings.push_back(Parking("", "Géant Casino", 3.922104130000000, 43.603155600000001));
  // parkings.push_back(Parking("", "Mare Nostrum", 3.919015140000000, 43.602370800000003));
  // parkings.push_back(Parking("", "Végapolis", 3.914773710000000, 43.602896510000001));
  // parkings.push_back(Parking("", "Multiplexe", 3.914110760000000, 43.604152429999999));
  // parkings.push_back(Parking("", "La Mantilla", 3.902399940000000, 43.598772959999998));

  for (Parking& parking : parkings)
  {
    if (parking.getId() != "") {
      std::map<String, String> infos = service.getParkingInfos(parking.getId());
      parking.setPlacesLibres(infos["free"].toInt());
      parking.setNbPlaces(infos["total"].toInt());
    }
  }
}

const std::vector<Parking>& ParkingsController::getParkings() const
{
  return parkings;
}

bool compareParkingsDistances(Parking* parking1, Parking* parking2, float longi, float lati, DistanceService& distanceService) {

  return parking1->getDistance(longi, lati, distanceService) < parking2->getDistance(longi, lati, distanceService);
}

const std::vector<Parking>& ParkingsController::getNearestParkings(float longi, float lati, DistanceService& distanceService, int nbParkings)
{

  // Serial.println("[i] Tri du proche au plus loin");
  std::sort(parkings.begin(), parkings.end(), [longi, lati, &distanceService](Parking& p1, Parking& p2) { return compareParkingsDistances(&p1, &p2, longi, lati, distanceService); });
 
  return parkings;
}

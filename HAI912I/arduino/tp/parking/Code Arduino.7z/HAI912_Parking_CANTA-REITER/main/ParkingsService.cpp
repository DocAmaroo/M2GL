#include "ParkingsService.h"
#include <string> 

String getXMLValue(String payload, String xmlKey) {
  if(payload.indexOf("<"+xmlKey+">")>0){
     int CountChar=xmlKey.length();
     int indexStart=payload.indexOf("<"+xmlKey+">");
     int indexStop= payload.indexOf("</"+xmlKey+">");  
     return payload.substring(indexStart+CountChar+2, indexStop);
  }
  return "";
}

std::map<String, String> ParkingsService::getParkingInfos(const String id)
{
  std::map<String, String> infos;

  http.begin(String(MONTPELLIER3M_URL) + id + String(MONTPELLIER3M_XML));
  int codeHttp = http.GET();
  
  if(codeHttp > 0) {
    if(codeHttp == HTTP_CODE_OK || codeHttp == HTTP_CODE_MOVED_PERMANENTLY) {
      String payload = http.getString();
      infos.insert(std::make_pair("free", getXMLValue(payload, "Free")));
      infos.insert(std::make_pair("total", getXMLValue(payload, "Total")));
    }
  } else {
    
  }
  return infos;
}
